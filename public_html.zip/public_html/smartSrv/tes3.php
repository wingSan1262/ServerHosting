<!DOCTYPE html>
<html>
<body>

<?php
$jsonobj = '{"Peter":35,"Ben":37,"Joe":43}';
 
echo(json_decode($jsonobj));
?>

</body>
</html>